var APP_DATA = {
  "scenes": [
    {
      "id": "0-atelier-composites",
      "name": "Atelier composites",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": 1.52819413066804,
        "pitch": 0.1651986167069559,
        "fov": 1.7670266911117383
      },
      "linkHotspots": [
        {
          "yaw": 0.7729705373578746,
          "pitch": 0.007130510633116316,
          "rotation": 6.283185307179586,
          "target": "1-atelier-plasturgie"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.005531186158847845,
          "pitch": -0.1488648156120611,
          "title": "Extrusion gonflage",
          "text": "Cette technique de plasturgie permet d'otenir, à partir de bille de plastique, des sacs poubelle, des sacs congélation ou encore des bâches de grandes dimensions."
        },
        {
          "yaw": 0.8615488781110088,
          "pitch": 0.20193763947870025,
          "title": "Table de découpe",
          "text": "Cette permet la découpe des renforts en fibres de verre qui rentreront dans la structure des pièces composites"
        },
        {
          "yaw": 1.718490809309536,
          "pitch": -0.0062463227130376,
          "title": "Renforts verre",
          "text": "Différents rouleaux de fibres de verres à utiliser en fonction du cahier des&nbsp; charges."
        },
        {
          "yaw": 2.376792866840166,
          "pitch": -0.031230383770438408,
          "title": "Cabine de peinture",
          "text": "Zone dédiée à la projection de gelcoat avec un pistolet à peinture."
        },
        {
          "yaw": -1.7038846756366421,
          "pitch": 0.019253890588174727,
          "title": "Etabli de stratification",
          "text": "C'est sur ces établis que nos élèves construisent les pièces à base de résine et de renforts en fibres de verre. Pour cela, ils utilisent des moules qui sont le négatif de la pièce à fabriquer."
        }
      ]
    },
    {
      "id": "1-atelier-plasturgie",
      "name": "Atelier Plasturgie",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.7162510409061316,
          "pitch": 0.1585792113552369,
          "rotation": 0,
          "target": "0-atelier-composites"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.7245984664447125,
          "pitch": 0.14208095586269742,
          "title": "Presse d'injection Engel",
          "text": "Sur cette presse, nos élèves viennent de produire 20 000 gobelets en matière bio à base de roseaux de Brenne."
        },
        {
          "yaw": -1.4925868768264436,
          "pitch": 0.12466561571216772,
          "title": "Presse d'injection Haitian",
          "text": "Sur cette presse, nos élèves vont prochainement produire des kits de rentrée (règle, équerre) en utilisant un plastique obtenu avec les masques chirurgicaux recyclés.<div><br></div>"
        },
        {
          "yaw": -0.8401977906885705,
          "pitch": 0.09631411335181994,
          "title": "Presse d'injection Arburg",
          "text": "A partir de bille de plastique, ce type machine permet la fabrication de pièce de différentes tailles et formes comme des lunettes, des interrupteurs, des crayons ou rasoirs BIC, des coques de téléphones, ...."
        },
        {
          "yaw": -0.47063304933819694,
          "pitch": 0.0801217618890071,
          "title": "Poste informatique",
          "text": "Différents postes informatique permettent aux élèves de compléter les documents liés aux différentes activités qu'ils ont à accomplir à l'atelier."
        },
        {
          "yaw": 0.6001131842431455,
          "pitch": 0.26462445531617895,
          "title": "Extrusion en ligne",
          "text": "C'est avec ce type de machine que sont produit les profilés de fenêtres, l'enrobage des câbles électriques , les tuyaux d'arrosage, et toutes sortes de produits rectilignes avec une section constante."
        },
        {
          "yaw": 2.1195787990840476,
          "pitch": 0.19997023677155745,
          "title": "Presse d'injection Arburg",
          "text": ""
        }
      ]
    }
  ],
  "name": "BAC PRO Plastiques et composites",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": true
  }
};
